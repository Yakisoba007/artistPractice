#include "library.h"
#include <QDir>
#include <QtDebug>
#include <QSqlError>

Library::Library(QWidget *parent) : QWidget(parent)
{
    mUi.setupUi(this);
    modelUser = new QSqlTableModel;
    modelUser->setTable("UserTable");
    modelUser->setEditStrategy(QSqlTableModel::OnManualSubmit);
    modelUser->select();

    mUi.userView->setModel(modelUser);
    mUi.userView->hideColumn(0);
    mUi.userView->horizontalHeader()->setStretchLastSection(true);

    modelTL = new QSqlTableModel;
    modelTL->setTable("TimelineTable");
    modelTL->setEditStrategy(QSqlTableModel::OnManualSubmit);
    modelTL->select();

    mUi.timelineView->setModel(modelTL);
    mUi.timelineView->hideColumn(0);
    mUi.timelineView->horizontalHeader()->setStretchLastSection(true);

    mUi.labelDir->setText("/home/kuen_ma/Programming/artistPractice/testLib");
    connect(mUi.pbSubmitUser, &QPushButton::clicked, modelUser, &QSqlTableModel::submitAll);
    connect(mUi.pbSubmitTL, &QPushButton::clicked, modelTL, &QSqlTableModel::submitAll);
}

Library::~Library()
{
    delete modelUser;
}

void Library::on_pbNewUser_clicked()
{
    bool ok;
    QString text = QInputDialog::getText(this, tr("New User Name"),
                                         tr("User name:"), QLineEdit::Normal,
                                         "Enter Username", &ok);
    if (ok && !text.isEmpty()) {
         QSqlQuery query;
         query.prepare("INSERT INTO UserTable (name) VALUES(:name)");
         query.bindValue(":name", text);
        query.exec();
        modelUser->submitAll();
    }

}

void Library::on_pbNewTL_clicked()
{
    bool ok;
    QString text = QInputDialog::getText(this, tr("New Timeline"),
                                         tr("Timeline:"), QLineEdit::Normal,
                                         "Enter comma seperated durations", &ok);
    if (ok && !text.isEmpty()) {
         QSqlQuery query;
         query.prepare("INSERT INTO TimelineTable (list) VALUES(:list)");
         query.bindValue(":list", text);
        query.exec();
        modelTL->submitAll();
    }

}

void Library::on_pbReload_clicked()
{

    QDir rootDir(mUi.labelDir->text());
    QSqlQuery qCat("SELECT name FROM CatTable");
    QStringList cats;
    while(qCat.next()) {
        cats << qCat.value(0).toString(); //TODO richtig?
    }
    qDebug() << cats;

    foreach(QFileInfo fp, rootDir.entryInfoList()) {
        if(fp.isDir() && !fp.baseName().isEmpty()) {
            if(!cats.contains(fp.baseName()) ) {
                QSqlQuery q;
                q.prepare("INSERT INTO catTable(name) VALUES(?)");
                q.addBindValue(fp.baseName());
                q.exec();
                qDebug() << fp.baseName();

            }
            int idCat;

            QSqlQuery q;
            q.prepare("SELECT IDcat FROM CatTable WHERE name LIKE ?");
            q.addBindValue(fp.baseName());
            q.exec();
            q.last();
            idCat = q.value("IDcat").toInt();

            QDir catDir(fp.filePath());
            qDebug() << catDir;
            catDir.setNameFilters({"*.jpg", "*.png", "*.bmp", "*.tif"});
            foreach(QString fileName, catDir.entryList(QDir::Files)) {
                qDebug() << catDir.absolutePath() + "/" + fileName;
                q.prepare("INSERT INTO RefTable(path, IDcat) VALUES(?,?)");
                q.addBindValue(catDir.absolutePath() + "/" + fileName);
                q.addBindValue(idCat);
                qDebug() << q.executedQuery();
                q.exec();
            }
        }
    }
}
