#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "timeline.h"
#include "configsession.h"
#include "library.h"

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();
private slots:
    void on_actionUser_triggered();
    void on_actionTimeline_triggered();
    void on_actionShowTL_triggered();

private:
    Ui::MainWindow *ui;
    QTabWidget *mTab;
    Timeline *mTimeline;
    ConfigSession *mCfgSession;
    Library *mLibrary;
    QString dir;
};

#endif // MAINWINDOW_H
