#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QtSql>
#include <QMessageBox>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    if(!QSqlDatabase::drivers().contains("QSQLITE"))
        QMessageBox::critical(this, "Unable to load database", "This demo needs the SQLITE driver");

    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName(qApp->applicationDirPath() + "/data.db");
    if(!db.open()) {
        QMessageBox::critical(this, "Unable to open database", "Can't open database");
    }

    mTab = new QTabWidget;
    mCfgSession = new ConfigSession;
    mTimeline = new Timeline;
    mLibrary = new Library;

    mTab->addTab(mCfgSession, "Configure Session");
    mTab->addTab(mLibrary, "Library");

    ui->Timeline->setWidget(mTimeline);
    setCentralWidget(mTab);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_actionUser_triggered()
{
}

void MainWindow::on_actionTimeline_triggered()
{
}

void MainWindow::on_actionShowTL_triggered()
{
    if(ui->Timeline->isHidden())
        ui->Timeline->show();
    else
        ui->Timeline->hide();
}
