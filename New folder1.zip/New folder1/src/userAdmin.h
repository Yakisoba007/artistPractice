/*
 * userAdmin.h
 *
 *  Created on: May 24, 2016
 *      Author: kuen_ma
 */

#ifndef USERADMIN_H_
#define USERADMIN_H_

class UserAdmin
{
public:
    UserAdmin();
    virtual ~UserAdmin();
};

#endif /* USERADMIN_H_ */
