#ifndef LIBRARY_H
#define LIBRARY_H

#include <QWidget>
#include "ui_library.h"
#include <QSqlTableModel>
#include <QInputDialog>
#include <QSqlQuery>

class Library : public QWidget
{
    Q_OBJECT
public:
    explicit Library(QWidget *parent = 0);
    virtual ~Library();
private slots:
    void on_pbNewUser_clicked();
    void on_pbNewTL_clicked();
    void on_pbReload_clicked();
private:
    Ui::Library mUi;
    QSqlTableModel *modelUser;
    QSqlTableModel *modelTL;
};

#endif // LIBRARY_H
