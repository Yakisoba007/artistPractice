/*
 * userAdmin.cpp
 *
 *  Created on: May 24, 2016
 *      Author: kuen_ma
 */

#include <src/userAdmin.h>

UserAdmin::UserAdmin()
{
    // TODO Auto-generated constructor stub

}

UserAdmin::~UserAdmin()
{
    // TODO Auto-generated destructor stub
}

