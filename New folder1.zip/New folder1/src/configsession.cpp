#include "configsession.h"

ConfigSession::ConfigSession(QWidget *parent) : QWidget(parent)
{
    mUi.setupUi(this);
}
