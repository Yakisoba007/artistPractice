#include "counter.h"

Counter::Counter(QWidget *parent) : QWidget(parent)
{
    mUi.setupUi(this);
}
